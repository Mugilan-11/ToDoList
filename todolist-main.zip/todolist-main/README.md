This the To-do list app made by HTML,CSS,JS. 
It takes your data as input and stores it in your local so that even refreshing the page you can get the same list that you store before
